# deevcs/__main__.py
from .cli import commands

if __name__ == "__main__":
    cli()
